-- MySQL dump 10.13  Distrib 5.1.51, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: orion_locations
-- ------------------------------------------------------
-- Server version	5.1.51-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_catalog`
--

DROP TABLE IF EXISTS `b_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CATALOG_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `LIST_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_PAGE_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PICTURE` int(18) DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SECTIONS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENTS_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEO_DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEO_KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock` (`CATALOG_TYPE_ID`,`SID`,`ACTIVE`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog`
--

LOCK TABLES `b_catalog` WRITE;
/*!40000 ALTER TABLE `b_catalog` DISABLE KEYS */;
INSERT INTO `b_catalog` VALUES (1,'2010-12-10 12:12:31','test','ru','','asdfasdf@@@','Y',100,'#SITE_DIR#/news/','#SITE_DIR#/news/#ELEMENT_ID#.html','#SITE_DIR#/news/#SECTION_ID#/',0,'','text','','','','','',''),(2,'2010-08-02 05:48:04','test','ru','one_more','one more','Y',200,'','','',0,'one more catalog','text','','','','','',''),(3,'2010-09-27 14:05:38','orion_locations','ru','TSZH','ТСЖ','Y',100,'/tszh/index.php','/tszh/element.php?ELEMENT_ID=#ID#','/tszh/section.php?SECTION_ID=#ID#',0,'Описание ТСЖ','text','','','','','',''),(4,'2010-09-27 14:04:17','orion_locations','ru','STREET','Улица','Y',200,'/street/','/street/element.php?ELEMENT_ID=#ID#','/street/section.php?SECTION_ID=#ID#',0,'Просто список улиц.','text','','','','','',''),(5,'2010-09-27 14:03:37','orion_locations','ru','BUILDINGS','Дома','Y',300,'/buildings/index.php','/buildings/section.php?SECTION_ID=#ID#','/buildings/?element.phpELEMENT_ID=#ID#',NULL,'Описание домов. Рабочая таблица','text',NULL,NULL,NULL,NULL,NULL,NULL),(6,'2010-09-27 14:30:27','orion_locations','ru','BUILDING_INFO','Информация о доме','Y',400,'/building_info/','/building_info/element.php?ELEMENT_ID=#ID#','/building_info/sectoin.php?SECTION_ID=#ID#',NULL,NULL,'text',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `b_catalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_element`
--

DROP TABLE IF EXISTS `b_catalog_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_element` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` datetime DEFAULT NULL,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `CATALOG_ID` int(11) NOT NULL DEFAULT '0',
  `CATALOG_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `DETAIL_TEXT` longtext COLLATE utf8_unicode_ci,
  `DETAIL_TEXT_TYPE` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `IN_SECTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAGS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SHOW_COUNTER` int(18) DEFAULT NULL,
  `SHOW_COUNTER_START` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_element_1` (`CATALOG_ID`,`CATALOG_SECTION_ID`),
  KEY `ix_iblock_element_4` (`CATALOG_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_element`
--

LOCK TABLES `b_catalog_element` WRITE;
/*!40000 ALTER TABLE `b_catalog_element` DISABLE KEYS */;
INSERT INTO `b_catalog_element` VALUES (1,'2010-07-18 13:26:07',1,'2010-07-18 13:26:07',1,1,0,'Y',NULL,NULL,100,'asdfasdf',NULL,NULL,'text',NULL,NULL,'text',NULL,'N','asdf',NULL,NULL,NULL),(2,'2010-07-18 13:28:49',1,'2010-07-18 13:28:49',1,1,0,'Y',NULL,NULL,100,'asdf',NULL,NULL,'text',NULL,NULL,'text',NULL,'N','asdf',NULL,NULL,NULL),(3,'2010-08-02 13:03:49',1,'2010-08-02 13:03:49',1,1,0,'Y',NULL,NULL,100,'asdasd',NULL,NULL,'text',NULL,NULL,'text',NULL,'N','asdasd',NULL,NULL,NULL),(4,'2010-08-14 18:00:07',1,'2010-08-14 18:00:07',1,2,0,'Y',NULL,NULL,100,'Element1',NULL,NULL,'text',NULL,NULL,'text',NULL,'N','element1',NULL,NULL,NULL),(5,'2011-01-29 23:07:38',1,'2010-09-27 22:32:15',1,1,0,'Y',NULL,NULL,5002444,'ТСЖ1111',NULL,'','0',NULL,'','0',NULL,'N','',NULL,NULL,NULL),(6,'2010-09-27 22:46:27',1,'2010-09-27 22:46:27',1,4,0,'Y',NULL,NULL,500,'Симпотичная',NULL,'Симпотичная улко','text',NULL,'Симпотичная улко - детально','text',NULL,'N',NULL,NULL,NULL,NULL),(7,'2010-10-01 19:21:24',1,'2010-10-01 19:21:24',1,3,0,'Y',NULL,NULL,500,'Новое ТСЖ',NULL,NULL,'text',NULL,NULL,'text',NULL,'N',NULL,NULL,NULL,NULL),(34,'2011-01-29 23:29:49',1,'2010-10-01 21:17:43',1,1,0,'Y',NULL,NULL,500,'asdfasdfasdfasdfasdfadsfasdfasdf',NULL,'Теперь текст меняется <b>на лету</b>','0',NULL,'','0',NULL,'N','',NULL,NULL,NULL),(36,'2011-01-30 00:19:55',1,'2010-10-01 21:18:41',1,1,0,'Y',NULL,NULL,500,'asdf66666666111',NULL,'','0',NULL,'','0',NULL,'N','',NULL,NULL,NULL),(37,'2011-01-30 00:25:06',1,'2010-10-01 21:25:10',1,1,0,'Y',NULL,NULL,500,'5555555%%%%',NULL,'','0',NULL,'','0',NULL,'N','',NULL,NULL,NULL),(38,'2010-10-30 19:28:46',0,'2010-10-01 21:36:43',1,3,0,'Y',NULL,NULL,500,'zxcv',NULL,'','0',NULL,'','',NULL,'N','',NULL,NULL,NULL),(39,'2011-01-30 00:24:19',1,'2010-10-01 21:45:49',1,1,0,'Y',NULL,NULL,500,'1!!!!!!!!!',NULL,'','0',NULL,'','0',NULL,'N','',NULL,NULL,NULL),(40,'2010-10-30 19:18:14',0,'2010-10-02 13:09:47',NULL,3,0,'Y',NULL,NULL,500,'asdf!!!!!!!!!!!!!!!!!!!',NULL,'','0',NULL,'','',NULL,'N','',NULL,NULL,NULL),(41,'2011-01-30 20:50:51',NULL,'2011-01-30 20:50:51',1,3,NULL,'Y',NULL,NULL,500,'@@@sadfgsdfg',NULL,NULL,'text',NULL,NULL,'text',NULL,'N','sdfgsdfg',NULL,NULL,NULL),(42,'2011-01-30 20:52:47',NULL,'2011-01-30 20:52:47',1,3,NULL,'Y',NULL,NULL,500,'@@@sadfgsdfg!!',NULL,NULL,'text',NULL,NULL,'text',NULL,'N',NULL,NULL,NULL,NULL),(43,'2011-01-30 20:53:47',NULL,'2011-01-30 20:53:47',1,3,NULL,'Y',NULL,NULL,500,'@asdfasdf',NULL,NULL,'text',NULL,NULL,'text',NULL,'N',NULL,NULL,NULL,NULL),(44,'2011-01-30 20:53:59',NULL,'2011-01-30 20:53:59',1,3,NULL,'Y',NULL,NULL,500,'@3sdfsdf',NULL,NULL,'text',NULL,NULL,'text',NULL,'N',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `b_catalog_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_element_property`
--

DROP TABLE IF EXISTS `b_catalog_element_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_element_property` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CATALOG_PROPERTY_ID` int(11) NOT NULL,
  `CATALOG_ELEMENT_ID` int(11) NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci NOT NULL,
  `VALUE_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `VALUE_ENUM` int(11) DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_element_property_1` (`CATALOG_ELEMENT_ID`,`CATALOG_PROPERTY_ID`),
  KEY `ix_iblock_element_property_2` (`CATALOG_PROPERTY_ID`),
  KEY `ix_iblock_element_prop_enum` (`VALUE_ENUM`,`CATALOG_PROPERTY_ID`),
  CONSTRAINT `b_catalog_element_property_ibfk_1` FOREIGN KEY (`CATALOG_ELEMENT_ID`) REFERENCES `b_catalog_element` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_element_property`
--

LOCK TABLES `b_catalog_element_property` WRITE;
/*!40000 ALTER TABLE `b_catalog_element_property` DISABLE KEYS */;
INSERT INTO `b_catalog_element_property` VALUES (1,1,5,'ул. Уличная 123- 2','text',NULL,NULL),(2,2,5,'ул. Симпатичная -321 - 12','text',NULL,NULL),(53,1,34,'asdf','text',NULL,NULL),(54,2,34,'asdf','text',NULL,NULL),(57,1,36,'asdf','text',NULL,NULL),(58,2,36,'asdf','text',NULL,NULL),(59,1,37,'asdf','text',NULL,NULL),(60,2,37,'asdf','text',NULL,NULL),(61,1,38,'asd','text',NULL,NULL),(62,2,38,'asdf','text',NULL,NULL),(63,1,39,'123','text',NULL,NULL),(64,2,39,'234','text',NULL,NULL),(65,1,40,'asdf','text',NULL,NULL),(66,2,40,'asdf','text',NULL,NULL);
/*!40000 ALTER TABLE `b_catalog_element_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_fields`
--

DROP TABLE IF EXISTS `b_catalog_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_fields` (
  `CATALOG_ID` int(18) NOT NULL,
  `FIELD_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`CATALOG_ID`,`FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_fields`
--

LOCK TABLES `b_catalog_fields` WRITE;
/*!40000 ALTER TABLE `b_catalog_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_catalog_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_group`
--

DROP TABLE IF EXISTS `b_catalog_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_group` (
  `CATALOG_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `PERMISSION` char(1) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `ux_iblock_group_1` (`CATALOG_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_group`
--

LOCK TABLES `b_catalog_group` WRITE;
/*!40000 ALTER TABLE `b_catalog_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_catalog_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_property`
--

DROP TABLE IF EXISTS `b_catalog_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_property` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CATALOG_ID` int(11) NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DEFAULT_VALUE` text COLLATE utf8_unicode_ci,
  `PROPERTY_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `ROW_COUNT` int(11) NOT NULL DEFAULT '1',
  `COL_COUNT` int(11) NOT NULL DEFAULT '30',
  `LIST_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'L',
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `XML_ID` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_TYPE` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MULTIPLE_CNT` int(11) DEFAULT NULL,
  `LINK_CATALOG_ID` int(18) DEFAULT NULL,
  `WITH_DESCRIPTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_REQUIRED` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_property_1` (`CATALOG_ID`),
  KEY `ix_iblock_property_2` (`CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_property`
--

LOCK TABLES `b_catalog_property` WRITE;
/*!40000 ALTER TABLE `b_catalog_property` DISABLE KEYS */;
INSERT INTO `b_catalog_property` VALUES (1,'2010-09-27 14:05:38',3,'Юр. Контакты','Y',500,'JUR_CONTACTS','','S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(2,'2010-09-27 14:05:38',3,'Физич. Контакты','Y',500,'PHYS_CONTACTS','','S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(3,'2010-09-27 14:03:37',5,'ТСЖ','Y',500,'TSZH_ID',NULL,'E',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(4,'2010-09-27 14:03:37',5,'Улица','Y',500,'STREET_ID',NULL,'S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(5,'2010-09-27 14:03:37',5,'Номер дома','Y',500,'BUILDING_NUMBER',NULL,'S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(6,'2010-09-27 14:30:27',6,'Дом','Y',500,'BUILDING_ID',NULL,'E',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(7,'2010-09-27 14:30:27',6,'Номер подъезда','Y',500,'ENTRENCE_NO',NULL,'S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(8,'2010-09-27 14:30:27',6,'Кол-во коммутаторов','Y',500,'COMM_QUANTITY',NULL,'S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(9,'2010-09-27 14:30:27',6,'Сейфы','Y',500,'SAFE',NULL,'S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(10,'2010-09-27 14:30:27',6,'Порты','Y',500,'PORTS',NULL,'S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL),(11,'2010-09-27 14:30:27',6,'Ключи','Y',500,'KEYS',NULL,'S',1,30,'L','N',NULL,NULL,NULL,NULL,NULL,'N',NULL);
/*!40000 ALTER TABLE `b_catalog_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_property_enum`
--

DROP TABLE IF EXISTS `b_catalog_property_enum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_property_enum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PROPERTY_ID` int(11) NOT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_property_enum`
--

LOCK TABLES `b_catalog_property_enum` WRITE;
/*!40000 ALTER TABLE `b_catalog_property_enum` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_catalog_property_enum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_section`
--

DROP TABLE IF EXISTS `b_catalog_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_section` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODIFIED_BY` int(18) DEFAULT NULL,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `CATALOG_ID` int(11) NOT NULL,
  `CATALOG_SECTION_ID` int(11) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `DEPTH_LEVEL` int(18) DEFAULT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `DETAIL_TEXT` longtext COLLATE utf8_unicode_ci NOT NULL,
  `DETAIL_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ix_iblock_section_1` (`CATALOG_ID`,`CATALOG_SECTION_ID`),
  KEY `ix_iblock_section_depth_level` (`CATALOG_ID`,`DEPTH_LEVEL`),
  KEY `ix_iblock_section_left_margin` (`CATALOG_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_section`
--

LOCK TABLES `b_catalog_section` WRITE;
/*!40000 ALTER TABLE `b_catalog_section` DISABLE KEYS */;
INSERT INTO `b_catalog_section` VALUES (1,'2010-08-14 10:44:55',NULL,'2010-08-14 18:44:55',1,2,NULL,'Y',500,'Секция',NULL,NULL,NULL,'0',NULL,'section',NULL,NULL,'','0'),(2,'2010-08-14 10:45:59',NULL,'2010-08-14 18:45:59',1,2,1,'Y',500,'Раздел',NULL,NULL,NULL,'0',NULL,'section1',NULL,NULL,'','0'),(3,'2010-08-14 10:48:05',NULL,'2010-08-14 18:48:05',1,2,NULL,'Y',500,'Секция3',NULL,NULL,NULL,'0',NULL,'section3',NULL,NULL,'','0');
/*!40000 ALTER TABLE `b_catalog_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_section_element`
--

DROP TABLE IF EXISTS `b_catalog_section_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_section_element` (
  `CATALOG_SECTION_ID` int(11) NOT NULL,
  `CATALOG_ELEMENT_ID` int(11) NOT NULL,
  `ADDITIONAL_PROPERTY_ID` int(18) DEFAULT NULL,
  UNIQUE KEY `ux_iblock_section_element` (`CATALOG_SECTION_ID`,`CATALOG_ELEMENT_ID`,`ADDITIONAL_PROPERTY_ID`),
  KEY `UX_IBLOCK_SECTION_ELEMENT2` (`CATALOG_ELEMENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_section_element`
--

LOCK TABLES `b_catalog_section_element` WRITE;
/*!40000 ALTER TABLE `b_catalog_section_element` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_catalog_section_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_site`
--

DROP TABLE IF EXISTS `b_catalog_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_site` (
  `CATALOG_ID` int(18) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CATALOG_ID`,`SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_site`
--

LOCK TABLES `b_catalog_site` WRITE;
/*!40000 ALTER TABLE `b_catalog_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_catalog_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_type`
--

DROP TABLE IF EXISTS `b_catalog_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_type` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(18) NOT NULL DEFAULT '500',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_type`
--

LOCK TABLES `b_catalog_type` WRITE;
/*!40000 ALTER TABLE `b_catalog_type` DISABLE KEYS */;
INSERT INTO `b_catalog_type` VALUES ('orion_locations',100),('test',200);
/*!40000 ALTER TABLE `b_catalog_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_catalog_type_lang`
--

DROP TABLE IF EXISTS `b_catalog_type_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_catalog_type_lang` (
  `CATALOG_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SECTION_NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ELEMENT_NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_catalog_type_lang`
--

LOCK TABLES `b_catalog_type_lang` WRITE;
/*!40000 ALTER TABLE `b_catalog_type_lang` DISABLE KEYS */;
INSERT INTO `b_catalog_type_lang` VALUES ('test','','Тестовый тип','',''),('orion_locations','','Местоположения Орион-Телеком','Раздел','Элемент');
/*!40000 ALTER TABLE `b_catalog_type_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_file`
--

DROP TABLE IF EXISTS `b_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_file` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HEIGHT` int(18) DEFAULT NULL,
  `WIDTH` int(18) DEFAULT NULL,
  `FILE_SIZE` int(18) NOT NULL,
  `CONTENT_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'IMAGE',
  `SUBDIR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ORIGINAL_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_file`
--

LOCK TABLES `b_file` WRITE;
/*!40000 ALTER TABLE `b_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_group`
--

DROP TABLE IF EXISTS `b_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_group` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(18) NOT NULL DEFAULT '100',
  `ANONYMOUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_group`
--

LOCK TABLES `b_group` WRITE;
/*!40000 ALTER TABLE `b_group` DISABLE KEYS */;
INSERT INTO `b_group` VALUES (1,'2009-09-08 05:47:36','Y',1,'N','Администраторы','Полный доступ к управлению сайтом.'),(2,'2009-09-08 05:47:36','Y',2,'Y','Все пользователи (в том числе неавторизованные)','Все пользователи, включая неавторизованных.');
/*!40000 ALTER TABLE `b_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_option`
--

DROP TABLE IF EXISTS `b_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_option` (
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `VALUE` text COLLATE utf8_unicode_ci,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  UNIQUE KEY `ix_option` (`MODULE_ID`,`NAME`,`SITE_ID`),
  KEY `ix_option_name` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_option`
--

LOCK TABLES `b_option` WRITE;
/*!40000 ALTER TABLE `b_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_site_template`
--

DROP TABLE IF EXISTS `b_site_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_site_template` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CONDITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `TEMPLATE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_site_template`
--

LOCK TABLES `b_site_template` WRITE;
/*!40000 ALTER TABLE `b_site_template` DISABLE KEYS */;
INSERT INTO `b_site_template` VALUES (1,'ru','',1,'main');
/*!40000 ALTER TABLE `b_site_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_user`
--

DROP TABLE IF EXISTS `b_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_user` (
  `ID` int(18) NOT NULL AUTO_INCREMENT,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LOGIN` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CHECKWORD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_LOGIN` datetime DEFAULT NULL,
  `DATE_REGISTER` datetime NOT NULL,
  `SID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PROFESSION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_WWW` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ICQ` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_GENDER` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_PHOTO` int(18) DEFAULT NULL,
  `PERSONAL_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_MOBILE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STREET` text COLLATE utf8_unicode_ci,
  `PERSONAL_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_STATE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_ZIP` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_NOTES` text COLLATE utf8_unicode_ci,
  `WORK_COMPANY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_POSITION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WORK_PHONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ADMIN_NOTES` text COLLATE utf8_unicode_ci,
  `STORED_HASH` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERSONAL_BIRTHDAY` date DEFAULT NULL,
  `CHECKWORD_TIME` datetime DEFAULT NULL,
  `SECOND_NAME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONFIRM_CODE` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGIN_ATTEMPTS` int(18) DEFAULT NULL,
  `LAST_ACTIVITY_DATE` datetime DEFAULT NULL,
  `LANG_ID` int(2) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ix_login` (`LOGIN`),
  KEY `ix_b_user_email` (`EMAIL`(191)),
  KEY `ix_b_user_activity_date` (`LAST_ACTIVITY_DATE`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_user`
--

LOCK TABLES `b_user` WRITE;
/*!40000 ALTER TABLE `b_user` DISABLE KEYS */;
INSERT INTO `b_user` VALUES (1,'2010-07-08 13:38:46','admin','95E495A24A3775A69C2F412942E18DD7',NULL,'Y','','','qw@er.ty',NULL,'0000-00-00 00:00:00','ru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `b_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_user_field`
--

DROP TABLE IF EXISTS `b_user_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_user_field` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FIELD_NAME` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) DEFAULT NULL,
  `MULTIPLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `IS_SEARCHABLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SETTINGS` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ux_user_type_entity` (`FIELD_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_user_field`
--

LOCK TABLES `b_user_field` WRITE;
/*!40000 ALTER TABLE `b_user_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_user_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_user_field_enum`
--

DROP TABLE IF EXISTS `b_user_field_enum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_user_field_enum` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_FIELD_ID` int(11) DEFAULT NULL,
  `VALUE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `XML_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_user_field_enum`
--

LOCK TABLES `b_user_field_enum` WRITE;
/*!40000 ALTER TABLE `b_user_field_enum` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_user_field_enum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_user_field_lang`
--

DROP TABLE IF EXISTS `b_user_field_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_user_field_lang` (
  `USER_FIELD_ID` int(11) NOT NULL DEFAULT '0',
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `LABEL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`USER_FIELD_ID`,`LANGUAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_user_field_lang`
--

LOCK TABLES `b_user_field_lang` WRITE;
/*!40000 ALTER TABLE `b_user_field_lang` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_user_field_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_user_group`
--

DROP TABLE IF EXISTS `b_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_user_group` (
  `USER_ID` int(18) NOT NULL,
  `GROUP_ID` int(18) NOT NULL,
  `DATE_ACTIVE_FROM` datetime DEFAULT NULL,
  `DATE_ACTIVE_TO` datetime DEFAULT NULL,
  UNIQUE KEY `ix_user_group` (`USER_ID`,`GROUP_ID`),
  KEY `ix_user_group_group` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_user_group`
--

LOCK TABLES `b_user_group` WRITE;
/*!40000 ALTER TABLE `b_user_group` DISABLE KEYS */;
INSERT INTO `b_user_group` VALUES (1,1,NULL,NULL),(1,2,NULL,NULL),(2,1,NULL,NULL);
/*!40000 ALTER TABLE `b_user_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-03-18 21:11:00
